//funkcja na zaladowanie dokumentu
$(function(){
    console.log("jquery works");
    
    //przykładowa funkcja na klikniecie diva w obszarze roboczym
    $("#right div").click(function(e){
      var index = $(e.target).index('#right div');
      console.log(index);
    });
    
    
})


